import { Inject, Injectable, NotFoundException } from '@nestjs/common';
import { Pool } from 'mysql2/promise';
import { ResultSetHeader, RowDataPacket } from 'mysql2';
import { KOKEN_DB } from '../config/database.config';

export interface KokenAlbum extends RowDataPacket {
  id: number;
  title: string;
  slug: string;
  visibility: string;
  created_on: number;
}

export interface KokenImage extends RowDataPacket {
  id: number;
  title?: string;
  caption?: string;
  filename?: string;
  favorite?: number;
  visibility?: string;
}

@Injectable()
export class KokenService {
  constructor(@Inject(KOKEN_DB) private readonly kokenDb: Pool) {}

  async listAlbums(): Promise<KokenAlbum[]> {
    const [rows] = await this.kokenDb.query<KokenAlbum[]>(
      `SELECT id, title, slug, visibility, created_on
       FROM koken_albums
       ORDER BY created_on DESC`
    );
    return rows;
  }

  async getAlbumById(id: number): Promise<KokenAlbum | null> {
    const [rows] = await this.kokenDb.query<KokenAlbum[]>(
      `SELECT id, title, slug, visibility, created_on 
       FROM koken_albums 
       WHERE id = ? 
       LIMIT 1`,
      [id]
    );
    return rows.length > 0 ? rows[0] : null;
  }

  async listImagesForAlbum(albumId: number): Promise<KokenImage[]> {
    const [rows] = await this.kokenDb.query<KokenImage[]>(
      `SELECT 
          c.id,
          c.title,
          c.caption,
          c.filename,
          c.favorite,
          c.internal_id,
          c.visibility
       FROM koken_join_albums_content jac
       INNER JOIN koken_content c ON c.id = jac.content_id
       WHERE jac.album_id = ?
       ORDER BY jac.order ASC`,
      [albumId]
    );
    return rows;
  }

  async writeFavoriteToKoken(imageId: number): Promise<void> {
    const [result] = await this.kokenDb.query<ResultSetHeader>(
      `UPDATE koken_content 
       SET favorite = 1, favorited_on = UNIX_TIMESTAMP() 
       WHERE id = ?`,
      [imageId]
    );
    if (result.affectedRows === 0) {
      throw new NotFoundException(`Image ${imageId} not found in Koken.`);
    }
  }

  async removeFavoriteFromKoken(imageId: number): Promise<void> {
    const [result] = await this.kokenDb.query<ResultSetHeader>(
      `UPDATE koken_content 
       SET favorite = 0, favorited_on = NULL 
       WHERE id = ?`,
      [imageId]
    );
    if (result.affectedRows === 0) {
      throw new NotFoundException(`Image ${imageId} not found in Koken.`);
    }
  }

  async getImageById(imageId: number): Promise<KokenImage | null> {
    const [rows] = await this.kokenDb.query<KokenImage[]>(
      `SELECT id, title, caption, filename, favorite, visibility 
       FROM koken_content 
       WHERE id = ? 
       LIMIT 1`,
      [imageId]
    );
    return rows.length > 0 ? rows[0] : null;
  }
}

