<?php

class Trash extends DataMapper
{
    public string $table = 'trash';
}

/* End of file trash.php */
/* Location: ./application/models/trash.php */
