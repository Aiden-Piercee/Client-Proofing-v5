<?php

class Setting extends DataMapper
{
    /**
     * Constructor: calls parent constructor
     */
    public function __construct($id = null)
    {
        parent::__construct($id);
    }
}

/* End of file category.php */
/* Location: ./application/models/category.php */
