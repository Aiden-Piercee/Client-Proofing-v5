<?php

class Application extends DataMapper
{
    public array $has_one = array(
        'user'
    );
}

/* End of file application.php */
/* Location: ./application/models/application.php */
