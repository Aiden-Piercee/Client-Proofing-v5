const BASE = "http://localhost:3700";

type Album = {
  id: number;
  title: string;
  slug: string;
};

type ProofingImage = {
  id: number;
  filename: string;
};

export default {
  async getAlbums(): Promise<Album[]> {
    return fetch(`${BASE}/albums`).then((r) => r.json());
  },

  async getImages(id: number): Promise<ProofingImage[]> {
    return fetch(`${BASE}/albums/${id}/images`).then((r) => r.json());
  },

  async setSelection(imageId: number, status: string) {
    return fetch(`${BASE}/selections/1/${imageId}`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ status })
    });
  }
};
