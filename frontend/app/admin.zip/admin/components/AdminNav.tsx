import Link from "next/link";

export default function AdminNav() {
  return (
    <aside className="w-64 bg-white shadow-md p-4 space-y-4">
      <h1 className="text-xl font-bold mb-4">Admin</h1>
      <nav className="flex flex-col space-y-2">
        <Link href="/admin/dashboard" className="text-neutral-700 hover:text-black">Dashboard</Link>
        <Link href="/admin/albums" className="text-neutral-700 hover:text-black">Albums</Link>
        <Link href="/admin/sessions" className="text-neutral-700 hover:text-black">Sessions</Link>
      </nav>
    </aside>
  );
}
