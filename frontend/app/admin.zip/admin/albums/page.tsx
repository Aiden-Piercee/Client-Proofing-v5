"use client";

import { useEffect, useState } from "react";
import Link from "next/link";

interface Album {
  id: number;
  title: string;
  imageCount: number;
  created_on?: number;
}

export default function AdminAlbumsPage() {
  const [albums, setAlbums] = useState<Album[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    async function load() {
      try {
        const API = process.env.NEXT_PUBLIC_API_URL;
        if (!API) throw new Error("NEXT_PUBLIC_API_URL missing");

        const token = localStorage.getItem("admin_token");
        if (!token) throw new Error("Missing admin token");

        const res = await fetch(`${API}/admin/albums`, {
          headers: {
            Authorization: `Bearer ${token}`,
          },
        });

        if (!res.ok) throw new Error("Failed to load albums");

        const data = await res.json();
        setAlbums(data);
      } catch (err: any) {
        console.error(err);
        setError(err.message);
      } finally {
        setLoading(false);
      }
    }

    load();
  }, []);

  if (loading) return <p>Loading albums…</p>;
  if (error) return <p className="text-red-600">Error: {error}</p>;

  return (
    <div>
      <h1 className="text-2xl font-semibold mb-4">Albums</h1>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        {albums.map((al) => (
          <Link href={`/admin/albums/${al.id}`} key={al.id}>
            <div className="p-4 bg-white shadow rounded-lg cursor-pointer hover:shadow-lg transition">
              <h2 className="font-medium text-lg">{al.title}</h2>
              <p className="text-sm text-neutral-500">
                {al.imageCount} images
              </p>
            </div>
          </Link>
        ))}
      </div>
    </div>
  );
}
