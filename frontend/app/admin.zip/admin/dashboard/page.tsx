export default function Dashboard() {
  return (
    <div>
      <h1 className="text-2xl font-semibold mb-4">Admin Dashboard</h1>
      <p>Welcome to the ClientProofing admin system.</p>
    </div>
  );
}
